class SalesService:
    def __init__(self, db, inventory):
        self.db = db
        self.inventory = inventory

    def sell(self, article_id, qty):
        self.db.execute(
            "INSERT INTO sales(article_id, qty) VALUES (?,?)",
            (article_id, qty)
        )
        self.inventory.adjust_stock(article_id, -qty, "Sprzedaż")
